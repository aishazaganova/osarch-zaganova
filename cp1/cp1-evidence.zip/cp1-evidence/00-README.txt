Evidence pack - office-srv
==========================
Collected by the helpdesk on Mon 2026-11-16 at about 09:42 UTC,
logged in over SSH as aigerim (member of sudo).

Each file holds the output of one command. The file name says which.
The first line of every file is the command itself.

If the command you want is not here, write in your transcript what you
would run and what you would expect, then carry on with what is here.

01-hostnamectl.txt                        hostnamectl
02-uptime.txt                             uptime
03-df-h.txt                               df -h
04-free-h.txt                             free -h
05-systemctl-failed.txt                   systemctl --failed
06-systemctl-list-timers.txt              systemctl list-timers
07-systemctl-status-nightly-report.txt    systemctl status nightly-report.service
08-systemctl-cat-nightly-report.txt       systemctl cat nightly-report.service nightly-report.timer
09-journalctl-nightly-report.txt          journalctl -u nightly-report.service
10-systemctl-status-legacy-sync.txt       systemctl status legacy-sync.service
11-journalctl-legacy-sync.txt             journalctl -u legacy-sync.service
12-journalctl-p-err-b.txt                 journalctl -p err -b
13-ls-l-usr-local-bin.txt                 ls -l /usr/local/bin
14-ls-l-var-log.txt                       ls -l /var/log
15-tail-nightly-report-log.txt            tail -n 20 /var/log/nightly-report.log
16-cat-nightly-report-sh.txt              cat /usr/local/bin/nightly-report.sh
17-cat-A-nightly-report-sh.txt            cat -A /usr/local/bin/nightly-report.sh
18-head-1-od-c.txt                        head -1 /usr/local/bin/nightly-report.sh | od -c
19-run-by-hand.txt                        running the script by hand, two ways
20-ls-l-bin-bash.txt                      which bash; ls -l /bin/bash
21-apt-history.txt                        tail -n 12 /var/log/apt/history.log
22-bash-history-aigerim.txt               tail -n 15 ~/.bash_history
